"""
generate_dataset.py
Generates a synthetic agricultural dataset for the Crop Yield / Risk
Classification problem. Real datasets vary by source, so this script
builds a plausible one from domain-informed rules + noise, which is
enough to demonstrate and evaluate the learning algorithms.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 600

soil_types = ["Loamy", "Clayey", "Sandy", "Silty"]
crop_types = ["Rice", "Wheat", "Maize", "Cotton", "Sugarcane"]
seasons = ["Kharif", "Rabi", "Zaid"]

rainfall = rng.normal(950, 350, N).clip(50, 2200)          # mm
temperature = rng.normal(27, 6, N).clip(8, 45)              # C
humidity = rng.normal(65, 15, N).clip(15, 100)              # %
soil_type = rng.choice(soil_types, N)
soil_pH = rng.normal(6.5, 0.9, N).clip(3.5, 9.5)
fertilizer = rng.normal(120, 45, N).clip(0, 300)            # kg/ha
pesticide = rng.normal(8, 4, N).clip(0, 30)                 # kg/ha
crop_type = rng.choice(crop_types, N)
area = rng.normal(3.2, 1.8, N).clip(0.2, 12)                # ha
season = rng.choice(seasons, N)

# --- Risk scoring rule (domain-informed, plus noise) -----------------
risk_score = np.zeros(N)
risk_score += np.where(rainfall < 500, 2.5, np.where(rainfall > 1600, 2.0, 0))
risk_score += np.where(temperature > 36, 2.0, np.where(temperature < 15, 1.5, 0))
risk_score += np.where((soil_pH < 5.0) | (soil_pH > 8.0), 1.5, 0)
risk_score += np.where(humidity < 30, 1.0, np.where(humidity > 90, 0.8, 0))
risk_score += np.where(fertilizer < 30, 0.8, 0)
risk_score += np.where(pesticide > 20, 0.7, 0)
risk_score += rng.normal(0, 0.9, N)  # noise

q1, q2 = np.quantile(risk_score, [0.45, 0.80])
risk_category = pd.cut(
    risk_score,
    bins=[-np.inf, q1, q2, np.inf],
    labels=["Low Risk", "Moderate Risk", "High Risk"],
)

df = pd.DataFrame({
    "Rainfall_mm": rainfall.round(1),
    "Temperature_C": temperature.round(1),
    "Humidity_pct": humidity.round(1),
    "Soil_Type": soil_type,
    "Soil_pH": soil_pH.round(2),
    "Fertilizer_kg_ha": fertilizer.round(1),
    "Pesticide_kg_ha": pesticide.round(2),
    "Crop_Type": crop_type,
    "Cultivated_Area_ha": area.round(2),
    "Season": season,
    "Risk_Category": risk_category.astype(str),
})

# introduce a few missing values to exercise the cleaning step
for col in ["Rainfall_mm", "Soil_pH", "Humidity_pct"]:
    idx = rng.choice(N, size=8, replace=False)
    df.loc[idx, col] = np.nan

df.to_csv("agriculture_dataset.csv", index=False)
print("Dataset written: agriculture_dataset.csv")
print(df["Risk_Category"].value_counts())
