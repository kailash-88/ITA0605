"""
results_runner.py
Runs the full pipeline non-interactively (same functions as
crop_risk_system.py) and saves outputs used to build the Results report:
  - results/summary.txt         (text metrics for all models)
  - results/model_comparison.csv
  - results/confusion_<model>.png
  - results/accuracy_comparison.png
  - results/risk_distribution.png
  - results/feature_importance.png (Decision Tree)
"""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

from crop_risk_system import (
    load_data, preprocess_data, statistical_summary,
    train_decision_tree, train_neural_network, train_genetic_algorithm,
    RANDOM_STATE, TARGET_COL,
)

import os
os.makedirs("results", exist_ok=True)

log_lines = []
def log(*args):
    line = " ".join(str(a) for a in args)
    print(line)
    log_lines.append(line)

df = load_data()
log(f"Dataset shape: {df.shape}")
log(f"Missing values before cleaning:\n{df.isna().sum()}")

X, X_scaled, y, encoders, target_encoder, scaler = preprocess_data(df)
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
)
log(f"\nTrain size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")

# ---- Risk distribution plot ----
plt.figure(figsize=(5, 4))
df[TARGET_COL].value_counts().reindex(["Low Risk", "Moderate Risk", "High Risk"]).plot(
    kind="bar", color=["#4C9A2A", "#E8A33D", "#C0392B"]
)
plt.title("Risk Category Distribution")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("results/risk_distribution.png", dpi=130)
plt.close()

results = {}

def run_and_capture(name, fn):
    result, model = fn(X_train, y_train, X_test, y_test, target_encoder)
    results[name] = (result, model)
    log(f"\n=== {name} ===")
    log(f"Accuracy: {result['accuracy']:.4f}")
    log(result["report"])
    return result, model

dt_result, dt_model = run_and_capture("Decision Tree", train_decision_tree)
nn_result, nn_model = run_and_capture("Neural Network (MLP)", train_neural_network)
ga_result, ga_model = run_and_capture("Genetic Algorithm", train_genetic_algorithm)

# ---- Confusion matrix plots ----
for name, (result, _) in results.items():
    cm = result["confusion_matrix"]
    labels = result["labels"]
    plt.figure(figsize=(4.5, 4))
    plt.imshow(cm, cmap="Blues")
    plt.title(f"Confusion Matrix: {name}")
    plt.xticks(range(len(labels)), labels, rotation=30, ha="right")
    plt.yticks(range(len(labels)), labels)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    for i in range(len(labels)):
        for j in range(len(labels)):
            plt.text(j, i, cm[i, j], ha="center", va="center",
                      color="white" if cm[i, j] > cm.max() / 2 else "black")
    plt.tight_layout()
    fname = f"results/confusion_{name.replace(' ', '_').replace('(', '').replace(')', '')}.png"
    plt.savefig(fname, dpi=130)
    plt.close()

# ---- Accuracy comparison plot ----
plt.figure(figsize=(5, 4))
names = list(results.keys())
accs = [results[n][0]["accuracy"] for n in names]
bars = plt.bar(names, accs, color=["#2E86AB", "#8E44AD", "#27AE60"])
plt.ylim(0, 1)
plt.ylabel("Test Accuracy")
plt.title("Model Accuracy Comparison")
plt.xticks(rotation=15, ha="right")
for b, a in zip(bars, accs):
    plt.text(b.get_x() + b.get_width() / 2, a + 0.02, f"{a:.3f}", ha="center")
plt.tight_layout()
plt.savefig("results/accuracy_comparison.png", dpi=130)
plt.close()

# ---- Feature importance (Decision Tree) ----
plt.figure(figsize=(5.5, 4))
importances = pd.Series(dt_model.feature_importances_, index=X.columns).sort_values()
importances.plot(kind="barh", color="#2E86AB")
plt.title("Decision Tree Feature Importance")
plt.tight_layout()
plt.savefig("results/feature_importance.png", dpi=130)
plt.close()

# ---- Save comparison CSV ----
comparison_df = pd.DataFrame({
    "Model": names,
    "Test Accuracy": [round(a, 4) for a in accs],
})
comparison_df.to_csv("results/model_comparison.csv", index=False)
log("\n--- Model Comparison Table ---")
log(comparison_df.to_string(index=False))

# ---- Sample prediction demo ----
from crop_risk_system import predict_new_sample
sample = {
    "Rainfall_mm": 420, "Temperature_C": 38.5, "Humidity_pct": 28,
    "Soil_Type": "Sandy", "Soil_pH": 4.6, "Fertilizer_kg_ha": 25,
    "Pesticide_kg_ha": 22, "Crop_Type": "Cotton", "Cultivated_Area_ha": 2.1,
    "Season": "Zaid",
}
pred = predict_new_sample(dt_model, encoders, target_encoder, scaler, X.columns, sample)
log(f"\nSample prediction (Decision Tree) for a low-rainfall/high-temperature/"
    f"acidic-soil case:\nInput: {sample}\nPredicted Risk Category: {pred}")

with open("results/summary.txt", "w") as f:
    f.write("\n".join(log_lines))

print("\nAll results saved to results/ directory.")
