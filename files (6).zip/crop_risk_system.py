"""
Intelligent Crop Yield Prediction and Agricultural Risk Classification System
--------------------------------------------------------------------------
Course : ITA0605 - Machine Learning (Slot-D)
Workflow: Dataset -> Preprocessing -> Statistical Analysis -> Feature
Selection -> Model Development (Decision Tree / Neural Network / Genetic
Algorithm) -> Prediction -> Model Evaluation -> Risk Classification.

Run interactively:   python3 crop_risk_system.py
Run non-interactively (for report generation): see results_runner.py
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

DATA_PATH = "agriculture_dataset.csv"
CATEGORICAL_COLS = ["Soil_Type", "Crop_Type", "Season"]
TARGET_COL = "Risk_Category"
RANDOM_STATE = 42


# ------------------------------------------------------------------ #
# 1. DATA LOADING & PREPROCESSING (pandas)
# ------------------------------------------------------------------ #
def load_data(path=DATA_PATH):
    df = pd.read_csv(path)
    print(f"Loaded {df.shape[0]} rows, {df.shape[1]} columns.")
    return df


def preprocess_data(df):
    df = df.copy()

    # --- Cleaning: fill missing numeric values with column median ---
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].median())

    # --- Encode categorical attributes ---
    encoders = {}
    for col in CATEGORICAL_COLS:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        encoders[col] = le

    target_encoder = LabelEncoder()
    df[TARGET_COL] = target_encoder.fit_transform(df[TARGET_COL])

    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]

    # --- Feature scaling (needed for the neural network) ---
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

    return X, X_scaled, y, encoders, target_encoder, scaler


def statistical_summary(df):
    print("\n--- Statistical Summary ---")
    print(df.describe(include="all").transpose())
    print("\n--- Risk Category Distribution ---")
    print(df[TARGET_COL].value_counts())
    print("\n--- Mean attribute values by Risk Category ---")
    print(df.groupby(TARGET_COL, observed=True).mean(numeric_only=True))


# ------------------------------------------------------------------ #
# 2. DECISION TREE MODEL
# ------------------------------------------------------------------ #
def train_decision_tree(X_train, y_train, X_test, y_test, target_encoder):
    model = DecisionTreeClassifier(
        criterion="entropy", max_depth=6, random_state=RANDOM_STATE
    )
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    return evaluate("Decision Tree", y_test, preds, target_encoder), model


# ------------------------------------------------------------------ #
# 3. NEURAL NETWORK (MLP w/ Backpropagation)
# ------------------------------------------------------------------ #
def train_neural_network(X_train, y_train, X_test, y_test, target_encoder):
    model = MLPClassifier(
        hidden_layer_sizes=(16, 8),
        activation="relu",
        solver="adam",
        max_iter=2000,
        random_state=RANDOM_STATE,
    )
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    return evaluate("Neural Network (MLP)", y_test, preds, target_encoder), model


# ------------------------------------------------------------------ #
# 4. GENETIC ALGORITHM - evolves per-class attribute-weight rules
# ------------------------------------------------------------------ #
class GeneticRuleClassifier:
    """
    Each chromosome encodes a weight vector per class (n_classes x n_features).
    A sample is scored against each class's weight vector (dot product);
    the class with the highest score is the prediction. The GA evolves
    the weight matrix (flattened chromosome) to maximise training accuracy.
    This mirrors GA-based hypothesis-space search over rule/weight space,
    as an alternative to greedy (tree) or gradient-based (MLP) search.
    """

    def __init__(self, n_classes, n_features, pop_size=40, generations=60,
                 mutation_rate=0.15, random_state=RANDOM_STATE):
        self.n_classes = n_classes
        self.n_features = n_features
        self.pop_size = pop_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.rng = np.random.default_rng(random_state)
        self.best_chromosome = None

    def _predict_with(self, chromosome, X):
        W = chromosome.reshape(self.n_classes, self.n_features)
        scores = X @ W.T
        return np.argmax(scores, axis=1)

    def _fitness(self, chromosome, X, y):
        preds = self._predict_with(chromosome, X)
        return np.mean(preds == y)

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)
        chrom_len = self.n_classes * self.n_features
        population = self.rng.normal(0, 1, size=(self.pop_size, chrom_len))

        for gen in range(self.generations):
            fitness = np.array([self._fitness(c, X, y) for c in population])
            order = np.argsort(-fitness)
            population = population[order]
            fitness = fitness[order]

            # elitism: keep top 20%
            n_elite = max(2, self.pop_size // 5)
            new_pop = [population[i] for i in range(n_elite)]

            # tournament selection + crossover + mutation
            while len(new_pop) < self.pop_size:
                p1 = self._tournament(population, fitness)
                p2 = self._tournament(population, fitness)
                cross_point = self.rng.integers(1, chrom_len)
                child = np.concatenate([p1[:cross_point], p2[cross_point:]])
                mutate_mask = self.rng.random(chrom_len) < self.mutation_rate
                child[mutate_mask] += self.rng.normal(0, 0.5, mutate_mask.sum())
                new_pop.append(child)

            population = np.array(new_pop)

        final_fitness = np.array([self._fitness(c, X, y) for c in population])
        self.best_chromosome = population[np.argmax(final_fitness)]
        return self

    def _tournament(self, population, fitness, k=3):
        idx = self.rng.integers(0, len(population), size=k)
        best = idx[np.argmax(fitness[idx])]
        return population[best]

    def predict(self, X):
        return self._predict_with(self.best_chromosome, np.asarray(X))


def train_genetic_algorithm(X_train, y_train, X_test, y_test, target_encoder):
    n_classes = len(np.unique(y_train))
    n_features = X_train.shape[1]
    model = GeneticRuleClassifier(n_classes=n_classes, n_features=n_features)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    return evaluate("Genetic Algorithm", y_test, preds, target_encoder), model


# ------------------------------------------------------------------ #
# 5. EVALUATION
# ------------------------------------------------------------------ #
def evaluate(name, y_test, preds, target_encoder):
    acc = accuracy_score(y_test, preds)
    labels = target_encoder.classes_
    report = classification_report(
        y_test, preds, target_names=labels, zero_division=0
    )
    cm = confusion_matrix(y_test, preds)
    print(f"\n=== {name} ===")
    print(f"Accuracy: {acc:.4f}")
    print(report)
    print("Confusion Matrix (rows=actual, cols=predicted):")
    print(pd.DataFrame(cm, index=labels, columns=labels))
    return {"name": name, "accuracy": acc, "report": report, "confusion_matrix": cm,
            "labels": labels}


# ------------------------------------------------------------------ #
# 6. PREDICTION ON A NEW SAMPLE
# ------------------------------------------------------------------ #
def predict_new_sample(model, encoders, target_encoder, scaler, feature_columns, sample: dict):
    row = pd.DataFrame([sample])
    for col in CATEGORICAL_COLS:
        row[col] = encoders[col].transform(row[col])
    row = row[feature_columns]
    row_scaled = pd.DataFrame(scaler.transform(row), columns=feature_columns)
    pred = model.predict(row_scaled)[0]
    return target_encoder.inverse_transform([pred])[0]


# ------------------------------------------------------------------ #
# 7. MENU-DRIVEN DRIVER
# ------------------------------------------------------------------ #
def main():
    df = None
    X = X_scaled = y = None
    encoders = target_encoder = scaler = None
    X_train = X_test = y_train = y_test = None
    trained = {}

    menu = """
==================================================================
 Intelligent Crop Yield Prediction & Agricultural Risk Classifier
==================================================================
 1. Load dataset
 2. Preprocess data (clean, encode, scale)
 3. View statistical summary
 4. Train & evaluate Decision Tree
 5. Train & evaluate Neural Network (MLP)
 6. Train & evaluate Genetic Algorithm
 7. Compare all trained models
 8. Predict risk for a new sample
 9. Exit
------------------------------------------------------------------
"""
    while True:
        print(menu)
        choice = input("Enter choice (1-9): ").strip()

        if choice == "1":
            df = load_data()

        elif choice == "2":
            if df is None:
                print("Load the dataset first (option 1).")
                continue
            X, X_scaled, y, encoders, target_encoder, scaler = preprocess_data(df)
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
            )
            print("Preprocessing complete. Train/test split created.")

        elif choice == "3":
            if df is None:
                print("Load the dataset first (option 1).")
                continue
            statistical_summary(df)

        elif choice == "4":
            if X_train is None:
                print("Preprocess the data first (option 2).")
                continue
            result, model = train_decision_tree(X_train, y_train, X_test, y_test, target_encoder)
            trained["Decision Tree"] = (result, model)

        elif choice == "5":
            if X_train is None:
                print("Preprocess the data first (option 2).")
                continue
            result, model = train_neural_network(X_train, y_train, X_test, y_test, target_encoder)
            trained["Neural Network (MLP)"] = (result, model)

        elif choice == "6":
            if X_train is None:
                print("Preprocess the data first (option 2).")
                continue
            result, model = train_genetic_algorithm(X_train, y_train, X_test, y_test, target_encoder)
            trained["Genetic Algorithm"] = (result, model)

        elif choice == "7":
            if not trained:
                print("Train at least one model first.")
                continue
            print("\n--- Model Comparison ---")
            for name, (result, _) in trained.items():
                print(f"{name:22s} Accuracy: {result['accuracy']:.4f}")

        elif choice == "8":
            if "Decision Tree" not in trained:
                print("Train the Decision Tree first (option 4) for this demo.")
                continue
            print("Enter new sample details:")
            sample = {
                "Rainfall_mm": float(input("Rainfall (mm): ")),
                "Temperature_C": float(input("Temperature (C): ")),
                "Humidity_pct": float(input("Humidity (%): ")),
                "Soil_Type": input(f"Soil Type {list(encoders['Soil_Type'].classes_)}: "),
                "Soil_pH": float(input("Soil pH: ")),
                "Fertilizer_kg_ha": float(input("Fertilizer (kg/ha): ")),
                "Pesticide_kg_ha": float(input("Pesticide (kg/ha): ")),
                "Crop_Type": input(f"Crop Type {list(encoders['Crop_Type'].classes_)}: "),
                "Cultivated_Area_ha": float(input("Cultivated Area (ha): ")),
                "Season": input(f"Season {list(encoders['Season'].classes_)}: "),
            }
            _, model = trained["Decision Tree"]
            pred = predict_new_sample(model, encoders, target_encoder, scaler, X.columns, sample)
            print(f"\nPredicted Risk Category: {pred}")

        elif choice == "9":
            print("Exiting. Goodbye.")
            break

        else:
            print("Invalid choice, try again.")


if __name__ == "__main__":
    main()
